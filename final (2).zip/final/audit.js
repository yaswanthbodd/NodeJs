function toggleFileUpload() {
    var landType = document.getElementById("landType").value;
    var fileUploadResidential = document.getElementById("fileUploadResidential");
    var fileUploadCommercial = document.getElementById("fileUploadCommercial");
    var fileUploadAgricultural = document.getElementById("fileUploadAgricultural");

    // Hide all file upload sections
    fileUploadResidential.classList.add("hidden");
    fileUploadCommercial.classList.add("hidden");
    fileUploadAgricultural.classList.add("hidden");

    // Show the selected file upload section based on land type
    if (landType === "residential") {
        fileUploadResidential.classList.remove("hidden");
    } else if (landType === "commercial") {
        fileUploadCommercial.classList.remove("hidden");
    } else if (landType === "agricultural") {
        fileUploadAgricultural.classList.remove("hidden");
    }
}
