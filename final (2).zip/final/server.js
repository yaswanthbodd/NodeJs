require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');

mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });

const landSchema = new mongoose.Schema({
    plotId: String,
    ownerName: String,
    landType: String,
    registrationDate: Date,
    amount: Number,
    coordinates: {
        lat: Number,
        lng: Number
    }
});

const Land = mongoose.model('Land', landSchema);

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});

app.post('/add-land', (req, res) => {
    const newLand = new Land({
        plotId: req.body.plotId,
        ownerName: req.body.ownerName,
        landType: req.body.landType,
        registrationDate: req.body.registrationDate,
        amount: req.body.amount,
        coordinates: {
            lat: req.body.lat,
            lng: req.body.lng
        }
    });

    newLand.save((err) => {
        if (!err) {
            res.send('Land added successfully!');
        } else {
            res.send(err);
        }
    });
});

app.listen(3000, () => {
    console.log('Server is running on port 3000');
});
